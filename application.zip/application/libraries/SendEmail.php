<?php 

class SendEmail {
	
	private $CI;
	private $from;

	public function __construct() {
		$this->CI = & get_instance();
		$this->CI->config->load('config-smtp', TRUE); 
		$smtp_config = $this->CI->config->item('config-smtp');
		$this->CI->load->library('email', $smtp_config);
		$this->from = $smtp_config['smtp_user'];
	}

	public function send($to, $subject, $message, $attachFilepath = [], $cc = [], $bcc = []) {

		try {
			if(!is_array($to)) {
				return false;
			}

			$toText = implode(', ', $to);
			
			$this->CI->email->set_newline("\r\n");
			$this->CI->email->from($this->from);
			$this->CI->email->to($toText);
			$this->CI->email->subject($subject);
			$this->CI->email->message($message);
			
			if(!empty($attachFilepath)) {
				foreach ($attachFilepath as $key => $value) {
					try {
						$this->CI->email->attach($value);
					} catch (Exception $e) { }
				}
			}

			if(!empty($cc) && is_array($cc)) {
				$ccText = implode(', ', $cc);
				$this->CI->email->cc($ccText);	
			}
			if(!empty($bcc) && is_array($bcc)) {
				$bccText = implode(', ', $bcc);
				$this->CI->email->bcc($bccText);	
			}
			
			if($this->CI->email->send()) {
				return true;
			} else {
				 return false;
			}
		} catch (Exception $e) {
			return $e;
		}
	}	
}