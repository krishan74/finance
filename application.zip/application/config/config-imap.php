<?php 
/**
* IMAP setting for Email Queue
*
*/
$config['imap_server'] = 'pop.secureserver.net';
$config['imap_username'] = 'gaurav@fixmyfinancials.in';
$config['imap_password'] = 'gaurav@123';
$config['imap_attachment_dir'] = FCPATH . 'assets/email-attachments';
$config['imap_port'] = '995';
$config['imap_string_url'] = '/pop3/ssl/novalidate-cert';
