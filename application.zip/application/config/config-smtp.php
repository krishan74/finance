<?php 
/**
* SMTP setting.
*
*/
$config = array(

  'protocol' => 'sendmail',

  'smtp_host' => 'smtpout.secureserver.net',

  'smtp_port' => 25,

  'smtp_user' => 'admin@neosisconsulting.in',

  'smtp_pass' => 'admin@123',

  'mailtype' => 'html',

  'charset' => 'iso-8859-1',

  'wordwrap' => TRUE

);
